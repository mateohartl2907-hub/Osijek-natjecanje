use anchor_lang::prelude::*;

declare_id!("VotingProgramId11111111111111111111111111111");

#[program]
pub mod voting {
    use super::*;

    /// Creates a new poll with a question and multiple options
    pub fn create_poll(
        ctx: Context<CreatePoll>,
        poll_id: u64,
        question: String,
        options: Vec<String>,
        ends_at: i64,
    ) -> Result<()> {
        require!(question.len() <= 280, VotingError::QuestionTooLong);
        require!(options.len() >= 2 && options.len() <= 10, VotingError::InvalidOptionsCount);
        require!(ends_at > Clock::get()?.unix_timestamp, VotingError::InvalidEndTime);

        let poll = &mut ctx.accounts.poll;
        poll.poll_id = poll_id;
        poll.creator = ctx.accounts.creator.key();
        poll.question = question;
        poll.options = options.clone();
        poll.vote_counts = vec![0u64; options.len()];
        poll.total_votes = 0;
        poll.created_at = Clock::get()?.unix_timestamp;
        poll.ends_at = ends_at;
        poll.is_active = true;
        poll.bump = ctx.bumps.poll;

        emit!(PollCreated {
            poll_id,
            creator: ctx.accounts.creator.key(),
            question: poll.question.clone(),
            options_count: poll.options.len() as u8,
        });

        Ok(())
    }

    /// Casts a vote for a specific option in a poll
    /// Each wallet can only vote once per poll (enforced by PDA)
    pub fn cast_vote(ctx: Context<CastVote>, poll_id: u64, option_index: u8) -> Result<()> {
        let poll = &mut ctx.accounts.poll;
        let vote_record = &mut ctx.accounts.vote_record;

        // Validate poll is still active
        require!(poll.is_active, VotingError::PollNotActive);
        require!(
            Clock::get()?.unix_timestamp < poll.ends_at,
            VotingError::PollEnded
        );

        // Validate option index
        require!(
            (option_index as usize) < poll.options.len(),
            VotingError::InvalidOption
        );

        // Record the vote (PDA ensures one vote per wallet per poll)
        vote_record.voter = ctx.accounts.voter.key();
        vote_record.poll_id = poll_id;
        vote_record.option_index = option_index;
        vote_record.voted_at = Clock::get()?.unix_timestamp;
        vote_record.bump = ctx.bumps.vote_record;

        // Update poll vote counts
        poll.vote_counts[option_index as usize] = poll
            .vote_counts[option_index as usize]
            .checked_add(1)
            .ok_or(VotingError::Overflow)?;
        poll.total_votes = poll
            .total_votes
            .checked_add(1)
            .ok_or(VotingError::Overflow)?;

        emit!(VoteCast {
            poll_id,
            voter: ctx.accounts.voter.key(),
            option_index,
        });

        Ok(())
    }

    /// Gets the results of a poll (read-only)
    /// Returns poll data including all vote counts
    pub fn get_results(ctx: Context<GetResults>, _poll_id: u64) -> Result<PollResults> {
        let poll = &ctx.accounts.poll;
        
        Ok(PollResults {
            poll_id: poll.poll_id,
            question: poll.question.clone(),
            options: poll.options.clone(),
            vote_counts: poll.vote_counts.clone(),
            total_votes: poll.total_votes,
            is_active: poll.is_active,
            ends_at: poll.ends_at,
        })
    }

    /// Closes a poll (only creator can close)
    pub fn close_poll(ctx: Context<ClosePoll>, _poll_id: u64) -> Result<()> {
        let poll = &mut ctx.accounts.poll;
        
        require!(
            ctx.accounts.creator.key() == poll.creator,
            VotingError::Unauthorized
        );
        
        poll.is_active = false;

        emit!(PollClosed {
            poll_id: poll.poll_id,
            total_votes: poll.total_votes,
        });

        Ok(())
    }
}

// ============================================================================
// ACCOUNTS
// ============================================================================

#[derive(Accounts)]
#[instruction(poll_id: u64)]
pub struct CreatePoll<'info> {
    #[account(
        init,
        payer = creator,
        space = Poll::SPACE,
        seeds = [b"poll", poll_id.to_le_bytes().as_ref()],
        bump
    )]
    pub poll: Account<'info, Poll>,

    #[account(mut)]
    pub creator: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(poll_id: u64)]
pub struct CastVote<'info> {
    #[account(
        mut,
        seeds = [b"poll", poll_id.to_le_bytes().as_ref()],
        bump = poll.bump
    )]
    pub poll: Account<'info, Poll>,

    #[account(
        init,
        payer = voter,
        space = VoteRecord::SPACE,
        seeds = [b"vote", poll_id.to_le_bytes().as_ref(), voter.key().as_ref()],
        bump
    )]
    pub vote_record: Account<'info, VoteRecord>,

    #[account(mut)]
    pub voter: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(poll_id: u64)]
pub struct GetResults<'info> {
    #[account(
        seeds = [b"poll", poll_id.to_le_bytes().as_ref()],
        bump = poll.bump
    )]
    pub poll: Account<'info, Poll>,
}

#[derive(Accounts)]
#[instruction(poll_id: u64)]
pub struct ClosePoll<'info> {
    #[account(
        mut,
        seeds = [b"poll", poll_id.to_le_bytes().as_ref()],
        bump = poll.bump
    )]
    pub poll: Account<'info, Poll>,

    pub creator: Signer<'info>,
}

// ============================================================================
// STATE
// ============================================================================

#[account]
pub struct Poll {
    pub poll_id: u64,
    pub creator: Pubkey,
    pub question: String,
    pub options: Vec<String>,
    pub vote_counts: Vec<u64>,
    pub total_votes: u64,
    pub created_at: i64,
    pub ends_at: i64,
    pub is_active: bool,
    pub bump: u8,
}

impl Poll {
    // Max space calculation:
    // 8 (discriminator) + 8 (poll_id) + 32 (creator) + 4 + 280 (question) +
    // 4 + (4 + 64) * 10 (options) + 4 + 8 * 10 (vote_counts) +
    // 8 (total_votes) + 8 (created_at) + 8 (ends_at) + 1 (is_active) + 1 (bump)
    pub const SPACE: usize = 8 + 8 + 32 + 4 + 280 + 4 + 680 + 4 + 80 + 8 + 8 + 8 + 1 + 1;
}

#[account]
pub struct VoteRecord {
    pub voter: Pubkey,
    pub poll_id: u64,
    pub option_index: u8,
    pub voted_at: i64,
    pub bump: u8,
}

impl VoteRecord {
    // 8 (discriminator) + 32 (voter) + 8 (poll_id) + 1 (option_index) + 8 (voted_at) + 1 (bump)
    pub const SPACE: usize = 8 + 32 + 8 + 1 + 8 + 1;
}

/// Return type for get_results instruction
#[derive(AnchorSerialize, AnchorDeserialize, Clone)]
pub struct PollResults {
    pub poll_id: u64,
    pub question: String,
    pub options: Vec<String>,
    pub vote_counts: Vec<u64>,
    pub total_votes: u64,
    pub is_active: bool,
    pub ends_at: i64,
}

// ============================================================================
// EVENTS
// ============================================================================

#[event]
pub struct PollCreated {
    pub poll_id: u64,
    pub creator: Pubkey,
    pub question: String,
    pub options_count: u8,
}

#[event]
pub struct VoteCast {
    pub poll_id: u64,
    pub voter: Pubkey,
    pub option_index: u8,
}

#[event]
pub struct PollClosed {
    pub poll_id: u64,
    pub total_votes: u64,
}

// ============================================================================
// ERRORS
// ============================================================================

#[error_code]
pub enum VotingError {
    #[msg("Question exceeds maximum length of 280 characters")]
    QuestionTooLong,
    #[msg("Poll must have between 2 and 10 options")]
    InvalidOptionsCount,
    #[msg("Poll end time must be in the future")]
    InvalidEndTime,
    #[msg("Poll is not active")]
    PollNotActive,
    #[msg("Poll has ended")]
    PollEnded,
    #[msg("Invalid option index")]
    InvalidOption,
    #[msg("Arithmetic overflow")]
    Overflow,
    #[msg("Unauthorized action")]
    Unauthorized,
}
