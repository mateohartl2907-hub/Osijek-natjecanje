import { PublicKey } from "@solana/web3.js";

export interface Poll {
  pollId: bigint;
  creator: PublicKey;
  question: string;
  options: string[];
  voteCounts: bigint[];
  totalVotes: bigint;
  createdAt: bigint;
  endsAt: bigint;
  isActive: boolean;
  bump: number;
}

export interface VoteRecord {
  voter: PublicKey;
  pollId: bigint;
  optionIndex: number;
  votedAt: bigint;
  bump: number;
}

export interface PollWithPublicKey {
  publicKey: PublicKey;
  account: Poll;
}

export interface CreatePollInput {
  question: string;
  options: string[];
  durationHours: number;
}

export interface CastVoteInput {
  pollId: bigint;
  optionIndex: number;
}
