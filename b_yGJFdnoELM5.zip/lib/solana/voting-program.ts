import {
  Connection,
  PublicKey,
  SystemProgram,
  TransactionInstruction,
} from "@solana/web3.js";
import * as borsh from "borsh";

// Program ID - Replace with your deployed program ID
export const VOTING_PROGRAM_ID = new PublicKey(
  "VotingProgramId11111111111111111111111111111"
);

// Instruction discriminators (first 8 bytes of sha256 hash of instruction name)
const CREATE_POLL_DISCRIMINATOR = Buffer.from([
  24, 148, 105, 37, 134, 209, 98, 217,
]);
const CAST_VOTE_DISCRIMINATOR = Buffer.from([
  193, 154, 109, 175, 94, 97, 84, 14,
]);

export interface PollAccount {
  pollId: bigint;
  creator: PublicKey;
  question: string;
  options: string[];
  voteCounts: bigint[];
  totalVotes: bigint;
  createdAt: bigint;
  endsAt: bigint;
  isActive: boolean;
  bump: number;
}

export interface VoteRecordAccount {
  voter: PublicKey;
  pollId: bigint;
  optionIndex: number;
  votedAt: bigint;
  bump: number;
}

// Get PDA for a poll
export function getPollPDA(pollId: bigint): [PublicKey, number] {
  const pollIdBuffer = Buffer.alloc(8);
  pollIdBuffer.writeBigUInt64LE(pollId);

  return PublicKey.findProgramAddressSync(
    [Buffer.from("poll"), pollIdBuffer],
    VOTING_PROGRAM_ID
  );
}

// Get PDA for a vote record
export function getVoteRecordPDA(
  pollId: bigint,
  voter: PublicKey
): [PublicKey, number] {
  const pollIdBuffer = Buffer.alloc(8);
  pollIdBuffer.writeBigUInt64LE(pollId);

  return PublicKey.findProgramAddressSync(
    [Buffer.from("vote"), pollIdBuffer, voter.toBuffer()],
    VOTING_PROGRAM_ID
  );
}

// Create poll instruction
export function createCreatePollInstruction(
  creator: PublicKey,
  pollId: bigint,
  question: string,
  options: string[],
  endsAt: bigint
): TransactionInstruction {
  const [pollPDA] = getPollPDA(pollId);

  // Serialize instruction data
  const pollIdBuffer = Buffer.alloc(8);
  pollIdBuffer.writeBigUInt64LE(pollId);

  const questionBuffer = Buffer.from(question, "utf-8");
  const questionLenBuffer = Buffer.alloc(4);
  questionLenBuffer.writeUInt32LE(questionBuffer.length);

  const optionsBuffers: Buffer[] = [];
  const optionsLenBuffer = Buffer.alloc(4);
  optionsLenBuffer.writeUInt32LE(options.length);
  optionsBuffers.push(optionsLenBuffer);

  for (const option of options) {
    const optionBuffer = Buffer.from(option, "utf-8");
    const optionLenBuffer = Buffer.alloc(4);
    optionLenBuffer.writeUInt32LE(optionBuffer.length);
    optionsBuffers.push(optionLenBuffer, optionBuffer);
  }

  const endsAtBuffer = Buffer.alloc(8);
  endsAtBuffer.writeBigInt64LE(endsAt);

  const data = Buffer.concat([
    CREATE_POLL_DISCRIMINATOR,
    pollIdBuffer,
    questionLenBuffer,
    questionBuffer,
    ...optionsBuffers,
    endsAtBuffer,
  ]);

  return new TransactionInstruction({
    keys: [
      { pubkey: pollPDA, isSigner: false, isWritable: true },
      { pubkey: creator, isSigner: true, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
    ],
    programId: VOTING_PROGRAM_ID,
    data,
  });
}

// Cast vote instruction
export function createCastVoteInstruction(
  voter: PublicKey,
  pollId: bigint,
  optionIndex: number
): TransactionInstruction {
  const [pollPDA] = getPollPDA(pollId);
  const [voteRecordPDA] = getVoteRecordPDA(pollId, voter);

  const pollIdBuffer = Buffer.alloc(8);
  pollIdBuffer.writeBigUInt64LE(pollId);

  const optionIndexBuffer = Buffer.alloc(1);
  optionIndexBuffer.writeUInt8(optionIndex);

  const data = Buffer.concat([
    CAST_VOTE_DISCRIMINATOR,
    pollIdBuffer,
    optionIndexBuffer,
  ]);

  return new TransactionInstruction({
    keys: [
      { pubkey: pollPDA, isSigner: false, isWritable: true },
      { pubkey: voteRecordPDA, isSigner: false, isWritable: true },
      { pubkey: voter, isSigner: true, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
    ],
    programId: VOTING_PROGRAM_ID,
    data,
  });
}

// Deserialize poll account
export function deserializePoll(data: Buffer): PollAccount {
  // Skip 8-byte discriminator
  let offset = 8;

  const pollId = data.readBigUInt64LE(offset);
  offset += 8;

  const creator = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;

  const questionLen = data.readUInt32LE(offset);
  offset += 4;
  const question = data.slice(offset, offset + questionLen).toString("utf-8");
  offset += questionLen;

  const optionsLen = data.readUInt32LE(offset);
  offset += 4;
  const options: string[] = [];
  for (let i = 0; i < optionsLen; i++) {
    const optLen = data.readUInt32LE(offset);
    offset += 4;
    options.push(data.slice(offset, offset + optLen).toString("utf-8"));
    offset += optLen;
  }

  const voteCountsLen = data.readUInt32LE(offset);
  offset += 4;
  const voteCounts: bigint[] = [];
  for (let i = 0; i < voteCountsLen; i++) {
    voteCounts.push(data.readBigUInt64LE(offset));
    offset += 8;
  }

  const totalVotes = data.readBigUInt64LE(offset);
  offset += 8;

  const createdAt = data.readBigInt64LE(offset);
  offset += 8;

  const endsAt = data.readBigInt64LE(offset);
  offset += 8;

  const isActive = data.readUInt8(offset) === 1;
  offset += 1;

  const bump = data.readUInt8(offset);

  return {
    pollId,
    creator,
    question,
    options,
    voteCounts,
    totalVotes,
    createdAt,
    endsAt,
    isActive,
    bump,
  };
}

// Fetch all polls from the program
export async function fetchAllPolls(
  connection: Connection
): Promise<{ publicKey: PublicKey; account: PollAccount }[]> {
  const accounts = await connection.getProgramAccounts(VOTING_PROGRAM_ID, {
    filters: [
      {
        // Poll discriminator - first 8 bytes
        memcmp: {
          offset: 0,
          bytes: "3VTLzycPMk4t", // Base58 encoded discriminator for Poll account
        },
      },
    ],
  });

  return accounts.map((acc) => ({
    publicKey: acc.pubkey,
    account: deserializePoll(acc.account.data as Buffer),
  }));
}

// Check if user has voted
export async function hasUserVoted(
  connection: Connection,
  pollId: bigint,
  voter: PublicKey
): Promise<boolean> {
  const [voteRecordPDA] = getVoteRecordPDA(pollId, voter);
  const account = await connection.getAccountInfo(voteRecordPDA);
  return account !== null;
}
