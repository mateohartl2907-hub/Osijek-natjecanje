"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Vote, Plus } from "lucide-react";

interface ActivityItem {
  id: string;
  type: "vote" | "create";
  wallet: string;
  pollQuestion: string;
  option?: string;
  timestamp: Date;
}

// Simulated live activity for demo purposes
const DEMO_ACTIVITIES: ActivityItem[] = [
  {
    id: "1",
    type: "vote",
    wallet: "7xKX...sAsU",
    pollQuestion: "Koji je najbolji blockchain za razvoj dApps?",
    option: "Solana",
    timestamp: new Date(Date.now() - 30000),
  },
  {
    id: "2",
    type: "vote",
    wallet: "9WzD...DJPF",
    pollQuestion: "Koji programski jezik preferirate za smart contracte?",
    option: "Rust",
    timestamp: new Date(Date.now() - 60000),
  },
  {
    id: "3",
    type: "create",
    wallet: "DYw8...NSKK",
    pollQuestion: "Trebamo li implementirati DAO governance?",
    timestamp: new Date(Date.now() - 120000),
  },
  {
    id: "4",
    type: "vote",
    wallet: "3KfR...mPqW",
    pollQuestion: "Trebamo li implementirati DAO governance?",
    option: "Da, apsolutno",
    timestamp: new Date(Date.now() - 180000),
  },
  {
    id: "5",
    type: "vote",
    wallet: "8HnJ...kLmN",
    pollQuestion: "Koji je najbolji blockchain za razvoj dApps?",
    option: "Ethereum",
    timestamp: new Date(Date.now() - 240000),
  },
];

export function LiveActivity() {
  const [activities, setActivities] = useState<ActivityItem[]>(DEMO_ACTIVITIES);
  const [isLive, setIsLive] = useState(true);

  // Simulate new activities coming in
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const wallets = [
        "5Abc...xYz1",
        "6Def...wVu2",
        "7Ghi...tSr3",
        "8Jkl...qPo4",
        "9Mno...nMl5",
      ];
      const options = ["Solana", "Ethereum", "Rust", "Solidity", "Da, apsolutno"];
      const questions = [
        "Koji je najbolji blockchain za razvoj dApps?",
        "Koji programski jezik preferirate za smart contracte?",
        "Trebamo li implementirati DAO governance?",
      ];

      const newActivity: ActivityItem = {
        id: Date.now().toString(),
        type: Math.random() > 0.9 ? "create" : "vote",
        wallet: wallets[Math.floor(Math.random() * wallets.length)],
        pollQuestion: questions[Math.floor(Math.random() * questions.length)],
        option: options[Math.floor(Math.random() * options.length)],
        timestamp: new Date(),
      };

      setActivities((prev) => [newActivity, ...prev.slice(0, 9)]);
    }, 5000);

    return () => clearInterval(interval);
  }, [isLive]);

  const formatTime = (date: Date) => {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h`;
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-foreground text-lg flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          Aktivnost uzivo
        </CardTitle>
        <button
          onClick={() => setIsLive(!isLive)}
          className="flex items-center gap-2"
        >
          <div
            className={`w-2 h-2 rounded-full ${
              isLive ? "bg-green-500 animate-pulse" : "bg-muted-foreground"
            }`}
          />
          <span className="text-xs text-muted-foreground">
            {isLive ? "UZIVO" : "PAUZIRANO"}
          </span>
        </button>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-80 overflow-y-auto">
          {activities.map((activity) => (
            <div
              key={activity.id}
              className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 border border-border"
            >
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  activity.type === "vote"
                    ? "bg-teal-100 text-teal-600"
                    : "bg-amber-100 text-amber-600"
                }`}
              >
                {activity.type === "vote" ? (
                  <Vote className="w-4 h-4" />
                ) : (
                  <Plus className="w-4 h-4" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm text-foreground">
                    {activity.wallet}
                  </span>
                  <Badge
                    variant="outline"
                    className="text-xs border-border text-muted-foreground"
                  >
                    {activity.type === "vote" ? "glasao" : "kreirao"}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground truncate mt-1">
                  {activity.type === "vote" && activity.option && (
                    <span className="text-primary font-medium">
                      {activity.option}
                    </span>
                  )}
                  {activity.type === "vote" && " na "}
                  {activity.pollQuestion.slice(0, 40)}...
                </p>
              </div>
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {formatTime(activity.timestamp)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
