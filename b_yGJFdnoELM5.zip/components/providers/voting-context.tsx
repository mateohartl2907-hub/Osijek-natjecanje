"use client";

import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";

// Demo poll data for hackathon presentation
// In production, this would be fetched from the Solana blockchain
export interface DemoPoll {
  id: string;
  pollId: bigint;
  creator: string;
  question: string;
  options: string[];
  voteCounts: number[];
  totalVotes: number;
  createdAt: Date;
  endsAt: Date;
  isActive: boolean;
}

export interface UserVote {
  pollId: string;
  optionIndex: number;
  votedAt: Date;
  txSignature: string;
}

export interface VoterRecord {
  walletAddress: string;
  optionIndex: number;
  votedAt: Date;
  txSignature: string;
}

interface VotingContextType {
  polls: DemoPoll[];
  userVotes: Map<string, UserVote>;
  pollVoters: Map<string, VoterRecord[]>;
  isLoading: boolean;
  createPoll: (
    question: string,
    options: string[],
    durationHours: number
  ) => Promise<DemoPoll>;
  castVote: (
    pollId: string,
    optionIndex: number,
    walletAddress: string
  ) => Promise<UserVote>;
  hasUserVoted: (pollId: string, walletAddress: string) => boolean;
  getPollById: (pollId: string) => DemoPoll | undefined;
  getPollVoters: (pollId: string) => VoterRecord[];
  refreshPolls: () => Promise<void>;
}

const VotingContext = createContext<VotingContextType | undefined>(undefined);

// Generate random wallet address for demo
const generateWallet = () => {
  const chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let result = "";
  for (let i = 0; i < 44; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

const generateTxSignature = () => {
  const chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  let result = "";
  for (let i = 0; i < 88; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

// Initial demo polls
const INITIAL_POLLS: DemoPoll[] = [
  {
    id: "poll-1",
    pollId: BigInt(1),
    creator: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
    question: "Koji je najbolji blockchain za razvoj dApps?",
    options: ["Solana", "Ethereum", "Polygon", "Avalanche"],
    voteCounts: [42, 28, 15, 8],
    totalVotes: 93,
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
    endsAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
    isActive: true,
  },
  {
    id: "poll-2",
    pollId: BigInt(2),
    creator: "9WzDXwBbmPEi5BGm1WNUXwE5zjNerYpyL3KxUn6nDJPF",
    question: "Koji programski jezik preferirate za smart contracte?",
    options: ["Rust", "Solidity", "Move", "Cairo"],
    voteCounts: [35, 45, 12, 8],
    totalVotes: 100,
    createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000),
    endsAt: new Date(Date.now() + 36 * 60 * 60 * 1000),
    isActive: true,
  },
  {
    id: "poll-3",
    pollId: BigInt(3),
    creator: "DYw8jCTfwHNRJhhmFcbXvVDTqWMEVFBX6ZKUmG5CNSKK",
    question: "Trebamo li implementirati DAO governance?",
    options: ["Da, apsolutno", "Mozda u buducnosti", "Ne, nije potrebno"],
    voteCounts: [78, 45, 12],
    totalVotes: 135,
    createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000),
    endsAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    isActive: true,
  },
];

// Generate initial demo voters for each poll
const generateInitialVoters = (): Map<string, VoterRecord[]> => {
  const votersMap = new Map<string, VoterRecord[]>();

  INITIAL_POLLS.forEach((poll) => {
    const voters: VoterRecord[] = [];
    poll.voteCounts.forEach((count, optionIndex) => {
      for (let i = 0; i < Math.min(count, 5); i++) {
        voters.push({
          walletAddress: generateWallet(),
          optionIndex,
          votedAt: new Date(
            poll.createdAt.getTime() +
              Math.random() * (Date.now() - poll.createdAt.getTime())
          ),
          txSignature: generateTxSignature(),
        });
      }
    });
    // Sort by votedAt descending
    voters.sort((a, b) => b.votedAt.getTime() - a.votedAt.getTime());
    votersMap.set(poll.id, voters);
  });

  return votersMap;
};

export function VotingProvider({ children }: { children: ReactNode }) {
  const [polls, setPolls] = useState<DemoPoll[]>(INITIAL_POLLS);
  const [userVotes, setUserVotes] = useState<Map<string, UserVote>>(new Map());
  const [pollVoters, setPollVoters] = useState<Map<string, VoterRecord[]>>(
    generateInitialVoters
  );
  const [isLoading, setIsLoading] = useState(false);

  const createPoll = useCallback(
    async (
      question: string,
      options: string[],
      durationHours: number
    ): Promise<DemoPoll> => {
      setIsLoading(true);

      // Simulate blockchain transaction delay
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const newPoll: DemoPoll = {
        id: `poll-${Date.now()}`,
        pollId: BigInt(polls.length + 1),
        creator: "YourWalletAddressHere",
        question,
        options,
        voteCounts: new Array(options.length).fill(0),
        totalVotes: 0,
        createdAt: new Date(),
        endsAt: new Date(Date.now() + durationHours * 60 * 60 * 1000),
        isActive: true,
      };

      setPolls((prev) => [newPoll, ...prev]);
      setPollVoters((prev) => new Map(prev).set(newPoll.id, []));
      setIsLoading(false);

      return newPoll;
    },
    [polls.length]
  );

  const castVote = useCallback(
    async (
      pollId: string,
      optionIndex: number,
      walletAddress: string
    ): Promise<UserVote> => {
      setIsLoading(true);

      // Simulate blockchain transaction delay
      await new Promise((resolve) => setTimeout(resolve, 1500));

      const voteKey = `${pollId}-${walletAddress}`;

      // Check if already voted
      if (userVotes.has(voteKey)) {
        setIsLoading(false);
        throw new Error("Already voted on this poll");
      }

      const txSignature = generateTxSignature();

      const userVote: UserVote = {
        pollId,
        optionIndex,
        votedAt: new Date(),
        txSignature,
      };

      const voterRecord: VoterRecord = {
        walletAddress,
        optionIndex,
        votedAt: new Date(),
        txSignature,
      };

      // Update poll vote counts
      setPolls((prev) =>
        prev.map((poll) => {
          if (poll.id === pollId) {
            const newVoteCounts = [...poll.voteCounts];
            newVoteCounts[optionIndex]++;
            return {
              ...poll,
              voteCounts: newVoteCounts,
              totalVotes: poll.totalVotes + 1,
            };
          }
          return poll;
        })
      );

      // Add voter record
      setPollVoters((prev) => {
        const newMap = new Map(prev);
        const existingVoters = newMap.get(pollId) || [];
        newMap.set(pollId, [voterRecord, ...existingVoters]);
        return newMap;
      });

      // Record user vote
      setUserVotes((prev) => new Map(prev).set(voteKey, userVote));
      setIsLoading(false);

      return userVote;
    },
    [userVotes]
  );

  const hasUserVoted = useCallback(
    (pollId: string, walletAddress: string): boolean => {
      const voteKey = `${pollId}-${walletAddress}`;
      return userVotes.has(voteKey);
    },
    [userVotes]
  );

  const getPollById = useCallback(
    (pollId: string): DemoPoll | undefined => {
      return polls.find((p) => p.id === pollId);
    },
    [polls]
  );

  const getPollVoters = useCallback(
    (pollId: string): VoterRecord[] => {
      return pollVoters.get(pollId) || [];
    },
    [pollVoters]
  );

  const refreshPolls = useCallback(async () => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 500));
    setIsLoading(false);
  }, []);

  return (
    <VotingContext.Provider
      value={{
        polls,
        userVotes,
        pollVoters,
        isLoading,
        createPoll,
        castVote,
        hasUserVoted,
        getPollById,
        getPollVoters,
        refreshPolls,
      }}
    >
      {children}
    </VotingContext.Provider>
  );
}

export function useVoting() {
  const context = useContext(VotingContext);
  if (!context) {
    throw new Error("useVoting must be used within a VotingProvider");
  }
  return context;
}
